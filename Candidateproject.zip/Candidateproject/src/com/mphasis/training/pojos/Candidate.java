package com.mphasis.training.pojos;

public class Candidate {
  private String name;
  private String technicalExpertise;
  private String city;
  private int yearsOfExperience;
  
  
@Override
public String toString() {
	return " " + name + ", " + technicalExpertise + "," + city
			+ ", " + yearsOfExperience;
}
public Candidate(String name, String technicalExpertise, String city, int yearsOfExperience) {
	super();
	this.name = name;
	this.technicalExpertise = technicalExpertise;
	this.city = city;
	this.yearsOfExperience = yearsOfExperience;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getTechnicalExpertise() {
	return technicalExpertise;
}
public void setTechnicalExpertise(String technicalExpertise) {
	this.technicalExpertise = technicalExpertise;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public int getYearsOfExperience() {
	return yearsOfExperience;
}
public void setYearsOfExperience(int yearsOfExperience) {
	this.yearsOfExperience = yearsOfExperience;
}
  
}
