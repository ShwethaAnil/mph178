package com.mphasis.training.basicprograms;

public class MovieApp {

	public static void main(String[] args) {
		

	}

}
