package com.mphasis.training.oops;

public class Acc {

}
