package com.mphasis.training.exceptions;

public class BuisnessException extends Exception {
public BuisnessException(String message) {
	super(message);
}
}

